## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE 
)

## ----setup--------------------------------------------------------------------
# library(pkmapr)
# library(dplyr)

