
# pkmapr: Pakistan Spatial Data Toolkit

<!-- badges: start -->

[![R-CMD-check](https://github.com/abdullahumer1101/pkmapr/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/abdullahumer1101/pkmapr/actions/workflows/R-CMD-check.yaml)
[![Codecov test
coverage](https://codecov.io/gh/abdullahumer1101/pkmapr/graph/badge.svg)](https://app.codecov.io/gh/abdullahumer1101/pkmapr)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.19769542.svg)](https://doi.org/10.5281/zenodo.19769542)
[![License: GPL
v3](https://img.shields.io/badge/License-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
<!-- badges: end -->

**pkmapr** (pronounced *P-K-Mapper*) provides a clean, tidy interface to
Pakistan’s official administrative boundary data from
[OCHA/HDX](https://data.humdata.org/dataset/cod-ab-pak). It downloads
and caches geometries at country, province, district, and tehsil level
as `sf` objects compatible with the tidyverse and geospatial ecosystem,
and includes utilities for geographic dictionary lookup, spatial
measurement, and neighbour structure construction for use with `spdep`,
`ggplot2`, `leaflet`, and related packages.

## Installation

``` r
# GitHub
remotes::install_github("abdullahumer1101/pkmapr")

# R-Universe
install.packages("pkmapr", repos = "https://abdullahumer1101.r-universe.dev")
```

## Quick start

``` r
library(pkmapr)

# Get province boundaries and map them
get_provinces() |> pk_map(title = "Pakistan provinces")

# Look up official names before joining
pk_dictionary("districts", province = "Punjab")

# Join your data and map
my_data <- data.frame(district_code = "PK603", value = 42)
get_districts() |>
  pk_join(my_data, by = "district_code") |>
  pk_map(fill = "value", title = "My data")
```

## Key functions

| Function | What it does |
|----|----|
| `get_country()`, `get_provinces()`, `get_districts()`, `get_tehsils()` | Download boundary geometries as `sf` objects |
| `pk_dictionary()` | Look up official names and PBS codes |
| `pk_join()` | Join data to geometries with unmatched-row warnings |
| `pk_neighbors()` | Build spatial weights for `spdep` with Pakistan-specific boundary handling |
| `pk_crs_suggest()` | Recommend the right projected CRS for your extent |
| `pk_map()`, `pk_map_interactive()` | Quick static and interactive maps |
| `pk_centroid()`, `pk_buffer()`, `pk_distance()` | Geometric operations in km |
| `pk_points_in()` | Assign GPS points to administrative units |

## Data source

Boundaries are sourced from the [OCHA Pakistan
COD-AB](https://data.humdata.org/dataset/cod-ab-pak), covering country,
province, district, and tehsil levels (577 tehsil features). Data are
released under CC BY licence.

## Citation

``` r
citation("pkmapr")
```

Or cite directly:

> Umer, A. (2025). pkmapr: Pakistan Spatial Data Toolkit.
> <https://doi.org/10.5281/zenodo.19769542>
